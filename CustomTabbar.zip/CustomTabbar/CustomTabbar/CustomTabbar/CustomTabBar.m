//
//  CustomTabBar.m
//  CustomTabbar
//
//  Created by dsc on 2018/4/11.
//  Copyright © 2018年 jsdtec. All rights reserved.
//

#import "CustomTabBar.h"
#import "CustomTabBarButton.h"

@interface CustomTabBar()

@property (nonatomic, assign) NSInteger index;
@property (nonatomic, strong) NSMutableArray *tabbarBtnArray;
@property (nonatomic, weak) UITabBarController *tabBarC;
@property (nonatomic,strong) CustomTabBarButton *customTabBarBtn;
@property(nonatomic, weak) CustomTabBarButton *selectedButton;
@end
@implementation CustomTabBar

- (NSMutableArray *)tabbarBtnArray{
    if (!_tabbarBtnArray) {
        _tabbarBtnArray = [NSMutableArray array];
    }
    return _tabbarBtnArray;
}

- (instancetype)initWithImageName:(NSString *)imageName title:(NSString *)title tabBarController:(UITabBarController *)tabBarC{
    self = [super init];
    if (self) {
        self.tabBarC = tabBarC;
    }
    return self;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    self.index = 0;
    for (UIView *subV in self.subviews) {
        if ([subV isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            [subV removeFromSuperview];
            
        } else if([subV isKindOfClass:[UIImageView class]] && subV.bounds.size.height <= 1){
            UIImageView *lineImage = (UIImageView *)subV;
            lineImage.hidden = YES;
        }
        
    }
    CGFloat btnY = 0;
    CGFloat btnW = self.frame.size.width/(self.tabbarBtnArray.count) - 1;
    CGFloat btnH = self.frame.size.height;
    
    
    for (int nIndex = 0; nIndex < self.tabbarBtnArray.count; nIndex++) {
        CGFloat btnX = btnW * nIndex;
        CustomTabBarButton *tabBarBtn = self.tabbarBtnArray[nIndex];
        if (nIndex == 1) {
            tabBarBtn.frame = CGRectMake(btnX, -OffsetY, btnW , btnH + OffsetY);
            tabBarBtn.backgroundColor = [UIColor clearColor];
            self.customTabBarBtn = tabBarBtn;
            ;
        } else{
            tabBarBtn.frame = CGRectMake(btnX, btnY, btnW, btnH);
        }
        
        tabBarBtn.tag = nIndex;
    }
}

- (void)addTabBarButtonWithTabBarItem:(UITabBarItem *)tabBarItem{
    CustomTabBarButton *tabBarBtn = [[CustomTabBarButton alloc] init];
    tabBarBtn.tabBarItem = tabBarItem;
    [tabBarBtn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchDown];
    [self addSubview:tabBarBtn];
    [self.tabbarBtnArray addObject:tabBarBtn];
    tabBarBtn.tag = self.tabbarBtnArray.count - 1;
    //default selected first one
    if (self.tabbarBtnArray.count == 3) {
        [self btnClick:tabBarBtn];
    }
}

- (void)btnClick:(CustomTabBarButton *)btn{
    self.tabBarC.selectedIndex = btn.tag;
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event{
    
    if (self.isHidden == NO) { // TabBar没有隐藏
        
        //将当前tabbar的触摸点转换坐标系，转换到中间按钮的身上，生成一个新的点
        CGPoint convertPoint = [self convertPoint:point toView:self.customTabBarBtn];
        
        //判断如果这个新的点是在中间按钮身上，那么处理点击事件最合适的view就是中间按钮
        if ([self.customTabBarBtn pointInside:convertPoint withEvent:event]) {
            return self.customTabBarBtn;
        }
        
    }
    
    return [super hitTest:point withEvent:event];
}

- (void)changeSelectedItem:(NSInteger)selectedIndex{
    
    CustomTabBarButton *itemBtn = [self.tabbarBtnArray objectAtIndex:selectedIndex];
    if ([itemBtn isKindOfClass:[CustomTabBarButton class]]) {
        self.selectedButton.selected = NO;
        itemBtn.selected = YES;
        self.selectedButton = itemBtn;
    }
}

@end
