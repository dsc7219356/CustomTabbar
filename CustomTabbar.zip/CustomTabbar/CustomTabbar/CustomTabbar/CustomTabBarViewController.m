//
//  CustomTabBarViewController.m
//  CustomTabbar
//
//  Created by dsc on 2018/4/11.
//  Copyright © 2018年 jsdtec. All rights reserved.
//
#define SUBJECTCORLOR [UIColor colorWithRed:57.0/255.0 green:170.0/255.0 blue:236.0/255.0 alpha:1.0]//通用色
#import "CustomTabBarViewController.h"
#import "CustomTabBar.h"
#import "BaseNavViewController.h"

#import "HomeViewController.h"
#import "CenterViewController.h"
#import "MineViewController.h"

@interface CustomTabBarViewController ()
@property(nonatomic, weak)CustomTabBar *mainTabBar;
@end

@implementation CustomTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                       [UIColor blackColor], NSForegroundColorAttributeName,
                                                       nil ,nil] forState:UIControlStateNormal];
    UIColor *titleHighlightedColor = SUBJECTCORLOR;
    [[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                       titleHighlightedColor, NSForegroundColorAttributeName,
                                                       nil, nil] forState:UIControlStateSelected];
    
    [[UITabBar appearance] setBarTintColor:[UIColor whiteColor]];//白色
    [UITabBar appearance].translucent = NO;
    [[UITabBar appearance] setShadowImage:[UIImage new]];
    //    [[UITabBar appearance] setBackgroundImage:[[UIImage alloc] init]];
    [self SetupMainTabBar];
    [self SetupAllControllers];
    [self addObserver:self forKeyPath:@"selectedIndex" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld context:nil];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if([keyPath isEqualToString:@"selectedIndex"]) {
        
        [_mainTabBar changeSelectedItem:self.selectedIndex];
    }
}

- (void)SetupMainTabBar{
    CustomTabBar *mainTabBar = [[CustomTabBar alloc] initWithImageName:@"" title:@"" tabBarController:self];
    mainTabBar.frame = self.tabBar.bounds;
    mainTabBar.delegate = self;
    
    [self setValue:mainTabBar forKey:@"tabBar"];
    
    _mainTabBar = mainTabBar;
}
- (void)SetupAllControllers{
    
    NSArray *titles = @[@"", @"", @""];
    NSArray *images = @[@"tab_live",@"tab_launch",@"tab_me"];
    NSArray *selectedImages = @[@"tab_live_p",@"tab_launch",@"tab_me_p",];
    
    HomeViewController *homeVC = [[HomeViewController alloc]init];
    CenterViewController *centerVC = [[CenterViewController alloc]init];
    MineViewController *mineVC  = [[MineViewController alloc]init];
    
    NSArray *viewControllers = @[homeVC,centerVC,mineVC];
    
    for (int i = 0; i < viewControllers.count; i++) {
        UIViewController *childVc = viewControllers[i];
        [self SetupChildVc:childVc title:titles[i] image:images[i] selectedImage:selectedImages[i]];
    }
    
}

- (void)SetupChildVc:(UIViewController *)childVc title:(NSString *)title image:(NSString *)imageName selectedImage:(NSString *)selectedImageName{
    BaseNavViewController *nav = [[BaseNavViewController alloc] initWithRootViewController:childVc];
    childVc.tabBarItem.image = [UIImage imageNamed:imageName];
    childVc.tabBarItem.selectedImage = [UIImage imageNamed:selectedImageName];
    childVc.tabBarItem.title = title;
    [self.mainTabBar addTabBarButtonWithTabBarItem:childVc.tabBarItem];
    [self addChildViewController:nav];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
