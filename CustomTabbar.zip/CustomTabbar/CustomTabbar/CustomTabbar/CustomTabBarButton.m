//
//  CustomTabBarButton.m
//  CustomTabbar
//
//  Created by dsc on 2018/4/11.
//  Copyright © 2018年 jsdtec. All rights reserved.
//

#define TabBarButtonImageRatio 0.6

#import "CustomTabBarButton.h"

@implementation CustomTabBarButton

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //只需要设置一次的放置在这里
        self.imageView.contentMode = UIViewContentModeScaleAspectFit;
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.font = [UIFont systemFontOfSize:11];
        [self setTitleColor:[UIColor brownColor] forState:UIControlStateSelected];
        [self setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
        //如果只需要图片，而不需要文字，可以这样设置，如果需要文字，38行需要放开
        [self sizeToFit];
        
    }
    return self;
}
//重写该方法可以去除长按按钮时出现的高亮效果
- (void)setHighlighted:(BOOL)highlighted
{
    
}

//-(CGRect)imageRectForContentRect:(CGRect)contentRect
//{
//    CGFloat imageW = contentRect.size.width;
//    CGFloat imageH = contentRect.size.height - TitleH - contentRect.size.width * 0.2;
//
//    return CGRectMake(0, contentRect.size.width * 0.1, imageW, imageH);
//}
//
//-(CGRect)titleRectForContentRect:(CGRect)contentRect
//{
//    CGFloat titleW = contentRect.size.width;
//    CGFloat titleY = contentRect.size.height - TitleH - contentRect.size.width * 0.05;
//
//    return CGRectMake(0, titleY, titleW, TitleH);
//}

- (void)setTabBarItem:(UITabBarItem *)tabBarItem
{
    _tabBarItem = tabBarItem;
    [self setTitle:self.tabBarItem.title forState:UIControlStateNormal];
    [self setImage:self.tabBarItem.image forState:UIControlStateNormal];
    [self setImage:self.tabBarItem.selectedImage forState:UIControlStateSelected];
}
@end
