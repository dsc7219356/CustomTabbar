//
//  CustomTabBar.h
//  CustomTabbar
//
//  Created by dsc on 2018/4/11.
//  Copyright © 2018年 jsdtec. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTabBar : UITabBar

- (instancetype)initWithImageName:(NSString *)imageName title:(NSString *)title tabBarController: (UITabBarController *)tabBarC;

- (void)addTabBarButtonWithTabBarItem:(UITabBarItem *)tabBarItem;

- (void)changeSelectedItem:(NSInteger)selectedIndex;
@end
