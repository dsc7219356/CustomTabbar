//
//  CustomTabBarViewController.h
//  CustomTabbar
//
//  Created by dsc on 2018/4/11.
//  Copyright © 2018年 jsdtec. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTabBarViewController : UITabBarController

@end
