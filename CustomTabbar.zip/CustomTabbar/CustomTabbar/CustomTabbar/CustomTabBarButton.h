//
//  CustomTabBarButton.h
//  CustomTabbar
//
//  Created by dsc on 2018/4/11.
//  Copyright © 2018年 jsdtec. All rights reserved.
//
#define TitleFont 10

#define TitleH 15

#define OffsetY 30

#define BtnH 49

#import <UIKit/UIKit.h>

@interface CustomTabBarButton : UIButton

@property (nonatomic, strong) UITabBarItem *tabBarItem;
@end
