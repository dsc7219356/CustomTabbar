//
//  AppDelegate.h
//  CustomTabbar
//
//  Created by dsc on 2018/4/9.
//  Copyright © 2018年 jsdtec. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

