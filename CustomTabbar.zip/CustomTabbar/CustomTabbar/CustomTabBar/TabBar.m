//
//  TabBar.m
//  CustomTabbar
//
//  Created by dsc on 2018/4/9.
//  Copyright © 2018年 jsdtec. All rights reserved.
//

#import "TabBar.h"
@interface TabBar()

@property (nonatomic, strong) UIImageView *tabbgView;

@property (nonatomic, strong) NSArray *dataList;

@property (nonatomic, strong) UIButton *lastItem;//记录上一次的点击按钮

@property (nonatomic, strong) UIButton *centerButton;//中间按钮
@end

@implementation TabBar

- (UIButton *)centerButton{
    if (!_centerButton) {
        _centerButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_centerButton setImage:[UIImage imageNamed:@"icon_meetsel"] forState:UIControlStateNormal];
        [_centerButton sizeToFit];
        [_centerButton addTarget:self action:@selector(clickItem:) forControlEvents:UIControlEventTouchUpInside];
        _centerButton.adjustsImageWhenHighlighted = NO;
        _centerButton.tag = ItemTypeCenter;
        
    }
    return _centerButton;
}
- (NSArray *)dataList{
    if (!_dataList) {
        _dataList = @[@"icon_home",@"icon_mine"];
    }
    return _dataList;
}

- (UIImageView *)tabbgView{
    if (!_tabbgView) {
        _tabbgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@""]];
    }
    return _tabbgView;
}
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //添加背景图
        [self addSubview:self.tabbgView];
        //加载按钮
        for (NSInteger i = 0; i < self.dataList.count; i++) {
            
            UIButton *item = [UIButton buttonWithType:UIButtonTypeCustom];
            //去除点击时的高亮状态
            item.adjustsImageWhenHighlighted = NO;
            
            [item setImage:[UIImage imageNamed:self.dataList[i]] forState:UIControlStateNormal];
            
            [item setImage:[UIImage imageNamed:[self.dataList[i]stringByAppendingString:@"sel"]] forState:UIControlStateSelected];
            
            [item addTarget:self action:@selector(clickItem:) forControlEvents:UIControlEventTouchUpInside];
            
            item.tag = ItemTypeHome + i;
            
            if (i == 0) {
                item.selected = YES;
                
                self.lastItem = item;
            }
            
            [self addSubview:item];
            
        }
        //添加中间突出的按钮
        
        [self addSubview:self.centerButton];
    }
    return self;
}
- (void)layoutSubviews{
    
    [super layoutSubviews];
    
    self.tabbgView.frame = self.bounds;
    CGFloat width = self.bounds.size.width / self.dataList.count;
    
    for (NSInteger i = 0; i<[self subviews].count; i++) {
        UIView *btn = [self subviews][i];
        
        if ([btn isKindOfClass:[UIButton class]]) {
            
          
            btn.frame = CGRectMake((btn.tag - ItemTypeHome)*width, 0, width, self.frame.size.height);
            
        }
    }
    [_centerButton sizeToFit];
    self.centerButton.center = CGPointMake(self.bounds.size.width/2, self.bounds.size.height - 49);
}

- (void)clickItem:(UIButton *)button{
    
    if ([self.delegate respondsToSelector:@selector(tabbar: clickButton:)]) {
        [self.delegate tabbar:self clickButton:button.tag];
    }
  
    //如果使用blcok
    //1.   !self.block?:self.block(self,button.tag)
    //2.    if (self.block) {
    //        self.block(self, button.tag);
    //    }
   
    //如果点击的是中间按钮，剩下的就不需要执行了，需求决定
    if (button.tag == ItemTypeCenter) {
      
        return;
    }
    
    self.lastItem.selected = NO;
    button.selected = YES;
    self.lastItem = button;
    
    
    //设置动画
    [UIView animateWithDuration:0.2 animations:^{
       
        button.transform = CGAffineTransformMakeScale(1.2, 1.2);
        
    }completion:^(BOOL finished) {
        [UIView animateWithDuration:0.2 animations:^{
            //恢复原始状态
            button.transform = CGAffineTransformIdentity;
            
        }];
    }];
    
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event{
    
    if (self.isHidden == NO) { // TabBar没有隐藏
        
        //将当前tabbar的触摸点转换坐标系，转换到中间按钮的身上，生成一个新的点
        CGPoint convertPoint = [self convertPoint:point toView:self.centerButton];
        
        //判断如果这个新的点是在中间按钮身上，那么处理点击事件最合适的view就是中间按钮
        if ([self.centerButton pointInside:convertPoint withEvent:event]) {
            return self.centerButton;
        }
        
    }
    
    return [super hitTest:point withEvent:event];
}

@end
