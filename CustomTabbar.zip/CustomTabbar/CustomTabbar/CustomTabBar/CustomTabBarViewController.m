//
//  CustomTabBarViewController.m
//  CustomTabbar
//
//  Created by dsc on 2018/4/9.
//  Copyright © 2018年 jsdtec. All rights reserved.
//
#define ScreenWidth                         [[UIScreen mainScreen] bounds].size.width
#define ScreenHeight                        [[UIScreen mainScreen] bounds].size.height
#import "CustomTabBarViewController.h"
#import "TabBar.h"
#import "BaseNavViewController.h"
#import "CenterViewController.h"
@interface CustomTabBarViewController ()<TabBarDelegate>

@property (nonatomic, strong) TabBar *customTabbar;


@end

@implementation CustomTabBarViewController

- (TabBar *)customTabbar{
    if (!_customTabbar) {
        _customTabbar = [[TabBar alloc]init];
                         //WithFrame:CGRectMake(0, 0, ScreenWidth, 49)];
        _customTabbar.delegate = self;
        
    }
    return _customTabbar;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //加载控制器
    [self configViewControllers];
    
     self.customTabbar.frame = self.tabBar.frame;
    //加载tabbr
     [self.view addSubview:self.customTabbar];
    
   

    //解决tabbar阴影线
    [[UITabBar appearance]setShadowImage:nil];
    [[UITabBar appearance] setBackgroundImage:nil];
    
}
- (void)configViewControllers{
    
    NSMutableArray *array = [NSMutableArray arrayWithArray:@[@"HomeViewController",@"MineViewController"]];
    
    for (NSInteger i = 0; i < array.count; i++) {
        
        NSString *vcName = array[i];
        
        UIViewController *vc = [[NSClassFromString(vcName) alloc]init];
        
        BaseNavViewController *nav = [[BaseNavViewController alloc]initWithRootViewController:vc];
        
        [array replaceObjectAtIndex:i withObject:nav];
        
        
    }
    self.viewControllers = array;
    
}
#pragma  mark -- tabbarDelegate
- (void)tabbar:(TabBar *)tabbar clickButton:(ItemType)index{
    
    if (index != ItemTypeCenter) {
        self.selectedIndex = index - ItemTypeHome;
        return;
    }
    
    //中间控制器模态弹出
    CenterViewController *vc = [[CenterViewController alloc]init];
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
