//
//  TabBar.h
//  CustomTabbar
//
//  Created by dsc on 2018/4/9.
//  Copyright © 2018年 jsdtec. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger ,ItemType) {
    
    ItemTypeCenter = 10,//中间
    ItemTypeHome = 100,//首页
    ItemTypeMe,//我的
};

@class TabBar;

typedef void(^TabBlock)(TabBar *tabbar,ItemType index);

@protocol TabBarDelegate <NSObject>

- (void)tabbar:(TabBar *)tabbar clickButton:(ItemType)index;

@end

@interface TabBar : UIView

@property (nonatomic, weak) id <TabBarDelegate>delegate;

@property (nonatomic, copy) TabBlock block;

@end
